LEGACY ARCHIVE 2019 - CLARA DB2 capacity material

Archived : 31/12/2019
Owner    : Derek Ollerton, DB2 Database Administrator (Leeds)

Contents
  capacity/DB2P_capacity_report_20191231.txt           year-end row count, reserve movement audit table
  capacity/reserve_movement_rowcount_20191231.csv      the same figure, machine-readable

Retention: keep with the CLARA technical archive.
